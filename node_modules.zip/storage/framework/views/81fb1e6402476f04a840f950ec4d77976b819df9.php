



<?php $__env->startSection('pageTitle', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <section id="main-container" class="main-container pb-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row shuffle">
                        <?php if( count($places) == 0): ?>
                            <p>
                                No place
                            </p>
                        <?php else: ?>
                            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 mb-5">
                                    <div class="ts-service-box">
                                        <div class="ts-service-image-wrapper">
                                        <img loading="lazy" class="w-100" src="<?php echo e(asset("images/".$place->images[1]->link)); ?>" alt="<?php echo e($place->images[1]->link); ?>">
                                        </div>
                                        <div class="d-flex">
                                        <div class="ts-service-box-img">
                                            <img loading="lazy" src="images/icon-image/service-icon1.png" alt="<?php echo e(asset("images/".$place->images[1]->link)); ?>">
                                        </div>
                                        <div class="ts-service-info">
                                            <h3 class="service-box-title"><a href="<?php echo e(route('places.show', $place->id)); ?>"><?php echo e($place->name); ?></a></h3>
                                            <p><?php echo e(Str::limit($place->description, 25)); ?></p>
                                            <a class="learn-more d-inline-block" href="<?php echo e(route('places.show', $place->id)); ?>" aria-label="service-details"><i class="fa fa-caret-right"></i> Learn more</a>
                                        </div>
                                        </div>
                                    </div><!-- Service2 end -->
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div><!-- shuffle end -->
                </div>

                <div class="col-12">
                    <div class="general-btn text-center">
                        <p><?php echo e($places->links()); ?></p>
                    </div>
                </div>
                
            </div><!-- Main row end -->
        </div><!-- Conatiner end -->
    </section>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/user/dashboard.blade.php ENDPATH**/ ?>