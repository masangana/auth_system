



<?php $__env->startSection('pageTitle', 'Search'); ?>

<?php $__env->startSection('content'); ?>


<section id="main-container" class="main-container">
    <div class="container">  
        <div class="row text-center">
            <div class="col-12">
              <h2 class="section-title">ReCherche</h2>
              <h3 class="section-sub-title">Find Our Location</h3>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filtre-events', [])->html();
} elseif ($_instance->childHasBeenRendered('rqnk8st')) {
    $componentId = $_instance->getRenderedChildComponentId('rqnk8st');
    $componentTag = $_instance->getRenderedChildComponentTagName('rqnk8st');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rqnk8st');
} else {
    $response = \Livewire\Livewire::mount('filtre-events', []);
    $html = $response->html();
    $_instance->logRenderedChild('rqnk8st', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-events', [])->html();
} elseif ($_instance->childHasBeenRendered('pn3Xb3S')) {
    $componentId = $_instance->getRenderedChildComponentId('pn3Xb3S');
    $componentTag = $_instance->getRenderedChildComponentTagName('pn3Xb3S');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pn3Xb3S');
} else {
    $response = \Livewire\Livewire::mount('show-events', []);
    $html = $response->html();
    $_instance->logRenderedChild('pn3Xb3S', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div
        


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/user/filter/event.blade.php ENDPATH**/ ?>