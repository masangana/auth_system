

<?php $__env->startSection('pageTitle', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<section id="main-container" class="main-container">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="row shuffle-wrapper">
            <div class="col-1 shuffle-sizer"></div>

            <?php if(count($events) == 0): ?>
              
            <?php else: ?>
              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <div class="col-lg-4 col-md-6 shuffle-item">
                  <div class="project-img-container">
                    <a  href="<?php echo e(route('events.show', $event->id)); ?>">
                      <?php if(count($event->categories) == 0): ?>
                        <img class="img-fluid" src="images/projects/project1.jpg" alt="project-image">
                      <?php else: ?>
                        <img class="img-fluid" src=" <?php echo e(asset("images/".$event->images[1]->link)); ?> " alt="<?php echo e($event->images[1]->link); ?>">
                      <?php endif; ?>
                      <span class="gallery-icon"><i class="fa fa-plus"></i></span>
                    </a>
                    <div class="project-item-info">
                      <div class="project-item-info-content">
                        <h3 class="project-item-title">
                          <a href="<?php echo e(route('events.show', $event->id)); ?>"><?php echo e($event->title); ?></a>
                        </h3>
                        <?php if(count($event->categories) == 0): ?>
                          
                        <?php else: ?>
                          <?php $__currentLoopData = $event->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <p class="project-cat"><?php echo e($category->name); ?></p>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                      </div>
                    </div>                
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <!-- shuffle item 1 end -->

          </div><!-- shuffle end -->
        </div>
  
        <div class="col-12">
          <div class="general-btn text-center">
            <?php echo e($events->links()); ?>

          </div>
        </div>
  
      </div>
    </div><!-- Conatiner end -->
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/user/event/index.blade.php ENDPATH**/ ?>