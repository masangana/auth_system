



<?php $__env->startSection('pageTitle', 'Search'); ?>

<?php $__env->startSection('content'); ?>


<section id="main-container" class="main-container">
    <div class="container">  
        <div class="row text-center">
            <div class="col-12">
              <h2 class="section-title">ReCherche</h2>
              <h3 class="section-sub-title">Find Our Location</h3>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filtre-services', [])->html();
} elseif ($_instance->childHasBeenRendered('bWF3dCy')) {
    $componentId = $_instance->getRenderedChildComponentId('bWF3dCy');
    $componentTag = $_instance->getRenderedChildComponentTagName('bWF3dCy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bWF3dCy');
} else {
    $response = \Livewire\Livewire::mount('filtre-services', []);
    $html = $response->html();
    $_instance->logRenderedChild('bWF3dCy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-services', [])->html();
} elseif ($_instance->childHasBeenRendered('xv7uO2t')) {
    $componentId = $_instance->getRenderedChildComponentId('xv7uO2t');
    $componentTag = $_instance->getRenderedChildComponentTagName('xv7uO2t');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xv7uO2t');
} else {
    $response = \Livewire\Livewire::mount('show-services', []);
    $html = $response->html();
    $_instance->logRenderedChild('xv7uO2t', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div
        


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/user/filter/service.blade.php ENDPATH**/ ?>