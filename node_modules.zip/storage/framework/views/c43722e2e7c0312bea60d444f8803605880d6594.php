
<div class="row">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-4 mb-5">
            <div class="ts-service-box-bg text-center h-100">
            <span class="ts-service-icon icon-round">
                <i class="fas fa-photo-video mr-0"></i>
            </span>
            <div class="ts-service-box-content">
                <h4>
                    <a href="">
                        <?php echo e($event->title); ?>

                    </a>
                </h4>
            </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH E:\web_projects\auth_system\resources\views/livewire/show-events.blade.php ENDPATH**/ ?>