

<?php $__env->startSection('pageTitle', 'show '); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card overflow-auto">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title"><?php echo e($place->name); ?></h4>
                <p class="card-description"> Details relatifs à <code><?php echo e($place->name); ?></code>
                </p>
                <hr style="border: 0; border-top: 1px solid #ccc;">
                <p class="overflow-auto">
                    <strong>Description : </strong> 
                    <br>
                    <?php echo e($place->description); ?>

                </p>
                <br>

                <hr style="border: 0; border-top: 1px solid #ccc;">
                <h5>Adresse </h5>   
                <?php if(count($place->adress) == 0): ?>
                  <p>
                    Aucune information actuellement
                  </p>
                <?php else: ?>
                  <p>
                      <strong>Commune : </strong><?php echo e($place->adress[0]->town); ?>

                      <br>
                      <strong>Quartier : </strong><?php echo e($place->adress[0]->district); ?>

                      <br>
                      <strong>Avenue : </strong><?php echo e($place->adress[0]->avenue); ?>, Nº <?php echo e($place->adress[0]->number); ?>

                      <br>
                  </p>
                <?php endif; ?>
                
              </div>
            </div>
          </div>
          <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Ajout d'un Service</h4>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                </p>
                <form class="forms-sample" method="POST" action="<?php echo e(Route('service.store', ['place'  => $place])); ?> ">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                      <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Nom</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="exampleInputUsername2" placeholder="Nom du service" name="title" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Type</label>
                      <div class="col-sm-9">
                          <select class="js-example-basic-multiple form-control"  name="type" style="width:100%" required>
                              <option value="">Selectionner un type</option>
                              <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div> 
                    </div>
                    <div class="form-group row">
                      <label for="minPrice" class="col-sm-3 col-form-label">Prix Minimum</label>
                      <div class="col-sm-9">
                        <input type="number" class="form-control" id="minPrice" placeholder="Prix min" name="minPrice" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="maxPrice" class="col-sm-3 col-form-label">Prix Maximal</label>
                      <div class="col-sm-9">
                        <input type="number" class="form-control" id="maxPrice" placeholder="Prix max" name="maxPrice" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="description" class="col-sm-3 col-form-label">Description du Service</label>
                      <div class="col-sm-9">
                        <textarea class="form-control" id="description" rows="4" name="description" ></textarea>
                      </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                  </form>
              </div>
            </div>
          </div>
    </div>

    <div class="row">
        <div class="col-md-6 col-xl-4 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="d-flex flex-row justify-content-between">
                <h4 class="card-title">Contact</h4>
              </div>
              <div class="preview-list">
                <?php if( count($place->contacts) == 0 ): ?>
                  <div class="preview-item">
                    <p>
                      Pas d'information
                    </p>
                  </div>
                <?php else: ?>
                  <div class="preview-item border-bottom">
                    <div class="preview-item-content d-flex flex-grow">
                      <div class="flex-grow">
                        <div class="d-flex d-md-block d-xl-flex justify-content-between">
                          <h6 class="preview-subject">Téléphone</h6>
                        </div>
                        <a class="text-muted" href="tel:<?php echo e($place->contacts[0]->phone); ?>" ><?php echo e($place->contacts[0]->phone); ?></a>
                      </div>
                    </div>
                  </div>
                  <div class="preview-item border-bottom">
                      <div class="preview-item-content d-flex flex-grow">
                        <div class="flex-grow">
                          <div class="d-flex d-md-block d-xl-flex justify-content-between">
                            <h6 class="preview-subject">Mail</h6>
                          </div>
                          <a class="text-muted" href="mailto:<?php echo e($place->contacts[0]->mail); ?>" ><?php echo e($place->contacts[0]->mail); ?></a>
                        </div>
                      </div>
                    </div>
                  <div class="preview-item border-bottom">
                      <div class="preview-item-content d-flex flex-grow">
                        <div class="flex-grow">
                          <div class="d-flex d-md-block d-xl-flex justify-content-between">
                            <h6 class="preview-subject">Site Web</h6>
                          </div>
                          <a class="text-muted" href="<?php echo e($place->contacts[0]->web_site); ?>" target="_blank"><?php echo e($place->contacts[0]->web_site); ?></a>
                        </div>
                      </div>
                  </div>
                <?php endif; ?>

                </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-xl-4 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Images Slide</h4>
              <div class="owl-carousel owl-theme full-width owl-carousel-dash portfolio-carousel" id="owl-carousel-basic">
                <?php if(count($place->images) == 0): ?>
                  Aucne image
                <?php else: ?>
                  <?php $__currentLoopData = $place->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="item">
                          <img src="<?php echo e(asset("images/".$image->link)); ?>" class="img-fluid img-thumbnail" alt="<?php echo e($image->link); ?> ">
                          <form method="post" action="<?php echo e(route('image.destroy', ['image' => $image->id])); ?>">
                              <?php echo method_field('delete'); ?>
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn ">
                                  <i class="mdi mdi-delete"></i>
                              </button>
                          </form> 
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 col-xl-4 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Liste des Services</h4>
              <div class="list-wrapper">
                <ul class="d-flex flex-column-reverse text-white todo-list todo-list-custom">
                  <?php if( count($place->services) == 0): ?>
                    <h5 class="text-danger">
                      Pas de service
                    </h5>
                  <?php else: ?>
                    <?php $__currentLoopData = $place->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="border-bottom" >
                        <div class="form-check form-check-primary">
                          <label class="form-check-label"> <?php echo e($service->title); ?>  </label>
                        </div>
                        
                          <form class="remove" method="post" action="<?php echo e(route('service.destroy', ['service' => $service->id])); ?>" >
                              <?php echo method_field('delete'); ?>
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn ">
                                  <i class=" mdi mdi-close-box"></i>
                              </button>
                          </form>
                        
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  <?php endif; ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
    </div>

    <div class="row">
      <div class="col-md-4 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Horaire d'ouverture</h4>
            <?php if( count($place->schedules) == 0 ): ?>
                  <div class="preview-item">
                    <p>
                      Pas d'information
                    </p>
                  </div>
            <?php else: ?>
                  <?php $__currentLoopData = $place->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="preview-item border-bottom">
                    <div class="preview-item-content d-flex flex-grow">
                      <div class="flex-grow">
                        <div class="d-flex d-md-block d-xl-flex justify-content-between">
                          <h6 class="preview-subject text-capitalize"><?php echo e($schedule->day); ?> </h6>
                          <p>
                            <?php echo e($schedule->open); ?> - <?php echo e($schedule->close); ?>

                          </p>
                          </div>
                        </div>
                      </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            <?php endif; ?>


          </div>
        </div>
      </div>
      <div class="col-md-8 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Horizontal Form</h4>
            <p class="card-description"> Horizontal form layout </p>
            <form class="forms-sample" method="POST" action="<?php echo e(Route('schedule.place', ['place'  => $place])); ?> ">
              <?php echo csrf_field(); ?>
              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked name="days[]" value="monday"> Lundi </label>
                </div>
                
                <div class="col-sm-3">
                  <input type="time" class="form-control" id="monday" name="mondayStart" >
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="monday" name="mondayEnd" >
                </div>
                
              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked value="tuesday" name="days[]"> Mardi </label>
                </div>            
                <div class="col-sm-3">
                  <input type="time" class="form-control" id="exampleInputUsername2" name="tuesdayStart" >
                </div>
                <div class="col-sm-3">
                  <input type="time" class="form-control" id="exampleInputUsername2" name="tuesdayEnd">
                </div>
              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked name="days[]" value="wednesday"> Mercredi </label>
                </div>             
                <div class="col-sm-3">
                  
                  <input type="time" class="form-control" id="Wednesday" name="wednesdayStart">
                </div>
                <div class="col-sm-3">
                  <input type="time" class="form-control" id="Wednesday" name="wednesdayEnd">
                </div>               
              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked name="days[]" value="thursday"> Jeudi </label>
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="thursday" name="thursdayStart">
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="thursday" name="thursdayEnd">
                </div>

              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked name="days[]" value="friday"> Vendredi </label>
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="friday" name="fridayStart">
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="friday" name="fridayEnd">
                </div>

              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" checked name="days[]" value="saturday"> Samedi </label>
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="saturday" name="saturdayStart">
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="saturday" name="saturdayEnd">
                </div>

              </div>

              <div class="form-group row">
                <div class="form-check col-sm-3">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="days[]" value="sunday"> Dimanche </label>
                </div>
                
                <div class="col-sm-3">
                  <input type="time" class="form-control" id="sundayStart" name="sundayStart">
                </div>

                <div class="col-sm-3">
                  <input type="time" class="form-control" id="sundayEnd" name="sundayEnd">
                </div>
                
              </div>
              
              <button type="submit" class="btn btn-primary mr-2">Submit</button>
              <button class="btn btn-dark">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/admin/place/show.blade.php ENDPATH**/ ?>