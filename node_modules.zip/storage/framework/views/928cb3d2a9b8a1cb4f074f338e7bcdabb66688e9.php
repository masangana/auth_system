<div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <input class="form-control" wire:model="query" wire:keyup.debounce="filter" type="text" placeholder="Recherche" class="border px-2">
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <input class="form-control" type="number" name="max" id="max" wire:model="max" wire:keyup.debounce="filter" placeholder="Prix Max du Service">
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <select class="form-control" wire:model="type" wire:change="filter" name="select" id="">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>    
    </div>
</div>
<?php /**PATH E:\web_projects\auth_system\resources\views/livewire/filtre-services.blade.php ENDPATH**/ ?>