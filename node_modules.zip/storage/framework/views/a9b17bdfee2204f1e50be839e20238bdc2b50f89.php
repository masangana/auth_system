

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('pageTitle'); ?> - Admin</title> 
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/css/vendor.bundle.base.css')); ?>">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/jvectormap/jquery-jvectormap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>">
    <!-- End plugin css for this page -->
    <!-- inject:css -->

    <!-- style for select box -->
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css')); ?>">
    <!-- end -->

    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo e(asset ('admin/assets/css/style.css')); ?>">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo e(asset ('admin/assets/images/favicon.png')); ?>" />
</head><?php /**PATH E:\web_projects\auth_system\resources\views/admin/layouts/head.blade.php ENDPATH**/ ?>