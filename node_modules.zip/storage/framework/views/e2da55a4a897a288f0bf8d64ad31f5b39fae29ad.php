<div id="top-bar" class="top-bar">

</div><?php /**PATH E:\web_projects\auth_system\resources\views/user/layouts/topbar.blade.php ENDPATH**/ ?>