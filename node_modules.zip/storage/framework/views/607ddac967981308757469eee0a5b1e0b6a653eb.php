



<?php $__env->startSection('pageTitle', '404'); ?>

<?php $__env->startSection('content'); ?>

<div id="banner-area" class="banner-area" style="background-image:url(<?php echo e(asset('user/images/banner/banner4.jpg')); ?>)">
    <div class="banner-text">
      <div class="container">
          <div class="row">
            <div class="col-lg-12">
                <div class="banner-heading">
                  <h1 class="banner-title">404</h1>
                  </nav>
                </div>
            </div><!-- Col end -->
          </div><!-- Row end -->
      </div><!-- Container end -->
    </div><!-- Banner text end -->
</div>
<section id="main-container" class="main-container">
    <div class="container">
  
      <div class="row">
  
        <div class="col-12">
          <div class="error-page text-center">
            <div class="error-code">
              <h2><strong>404</strong></h2>
            </div>
            <div class="error-message">
              <h3>Oops... Un Problème!</h3>
            </div>
            <div class="error-body">
                Essayez d'utiliser le bouton ci-dessous pour accéder à la page principale du site <br>
                <?php if(auth()->guard()->guest()): ?>
                    <a class="btn btn-primary" href="<?php echo e(Route('index')); ?>">
                        Acceuil
                    </a>
                <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo e(Route('home')); ?>">
                        Acceuil
                    </a>
                <?php endif; ?>
            </div>
          </div>
        </div>
  
      </div><!-- Content row -->
    </div><!-- Conatiner end -->
</section><!-- Main container end -->
  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/errors/404.blade.php ENDPATH**/ ?>