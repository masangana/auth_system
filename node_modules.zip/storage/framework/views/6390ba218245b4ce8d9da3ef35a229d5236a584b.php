
<div class="row">
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-4 mb-5">
            <div class="ts-service-box-bg text-center h-100">
            <span class="ts-service-icon icon-round">
                <i class="fas fa-map-marker-alt mr-0"></i>
            </span>
            <div class="ts-service-box-content">
                <h4>
                    <a href="<?php echo e(route('places.show', $service->place_id)); ?> ">
                        <?php echo e($service->title); ?>

                    </a>
                </h4>
                <p>De <strong><?php echo e($service->min_price); ?></strong>Fc à <strong><?php echo e($service->max_price); ?></strong>Fc</p>
                    <br>
                <p>
                    <span class="badge badge-success">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($type->id == $service->type_id): ?>
                            <?php echo e($type->name); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </p>
            </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!-- 1st row end -->
<?php /**PATH E:\web_projects\auth_system\resources\views/livewire/show-services.blade.php ENDPATH**/ ?>