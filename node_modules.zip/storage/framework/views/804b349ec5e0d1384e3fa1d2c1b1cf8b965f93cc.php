<div class="page-header">
    <h3 class="page-title"> <?php echo $__env->yieldContent('pageTitle'); ?> </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Charts</a></li>
        <li class="breadcrumb-item active" aria-current="page">Chart-js</li>
      </ol>
    </nav>
</div><?php /**PATH E:\web_projects\auth_system\resources\views/admin/layouts/breadcrumb.blade.php ENDPATH**/ ?>