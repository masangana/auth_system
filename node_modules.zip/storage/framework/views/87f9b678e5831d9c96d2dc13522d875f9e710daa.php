<div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <input class="form-control" wire:model="query" wire:keyup.debounce="filter" type="text" placeholder="Recherche" class="border px-2">
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <input class="form-control" type="date" name="start_date" id="start_date" wire:model="start_date" wire:keyup.debounce="filter" placeholder="Prix Max du Service">
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <input class="form-control" type="date" name="end_date" id="end_date" wire:model="end_date" wire:keyup.debounce="filter" placeholder="Prix Max du Service">
            </div>
        </div>

        <div class="col-md-3">
            <div class="form-group">
                <select class="form-control" wire:model="category" wire:change="filter" name="select" id="">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>    
    </div>
</div>
<?php /**PATH E:\web_projects\auth_system\resources\views/livewire/filtre-events.blade.php ENDPATH**/ ?>