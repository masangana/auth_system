<!-- Header start -->
<header id="header" class="header-two">
    <div class="site-navigation">
      <div class="container">
          <div class="row">
            <div class="col-lg-12">
                <nav class="navbar navbar-expand-lg navbar-light p-0">
                  
                  <div class="logo">
                        <?php if(auth()->guard()->guest()): ?>
                        <a class="d-block" href="<?php echo e(Route('index')); ?>">
                            <img loading="lazy" src="<?php echo e(asset('user/images/logo.png')); ?>" alt="Constra">
                        </a>
                        <?php else: ?>
                            <a class="d-block" href="<?php echo e(Route('home')); ?>">
                                <img loading="lazy" src="<?php echo e(asset('user/images/logo.png')); ?>" alt="Constra">
                            </a>
                        <?php endif; ?>
                      
                  </div><!-- logo end -->
  
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                  </button>
                  
                  <div id="navbar-collapse" class="collapse navbar-collapse">
                      <ul class="nav navbar-nav ml-auto align-items-center">
                        <li class="nav-item dropdown active">
                            <a href="<?php echo e(Route('user.dashboard')); ?>" class="nav-link dropdown-toggle">Lieux </a>
                        </li>

                        <li class="nav-item dropdown">
                            <a href="<?php echo e(Route('events.index')); ?>" class="nav-link dropdown-toggle">Events </a>
                        </li>
                
                        <li class="nav-item dropdown">
                            <a href="<?php echo e(Route('services.filter')); ?>" class="nav-link dropdown-toggle" >Services </a>
                        </li>

                        <li class="nav-item"><a class="nav-link" href="<?php echo e(Route('contact.mail')); ?>">Contact</a></li>

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="header-get-a-quote">
                                    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                  
                                <li class="header-get-a-quote">
                                    <a class="btn btn-primary" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                              <li>
                                  <span class="alert alert-primary" role="alert">
                                      <?php echo e(Auth::user()->name); ?> <i class="fa fa-user"></i>
                                  </span>
                              </li>
                              <li class="header-get-a-quote">
                                    <a class="btn btn-primary" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                      document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            </li>
                        <?php endif; ?>
                      </ul>
                  </div>
                </nav>
            </div>
            <!--/ Col end -->
          </div>
          <!--/ Row end -->
      </div>
      <!--/ Container end -->
  
    </div>
    <!--/ Navigation end -->
</header>
  <!--/ Header end --><?php /**PATH E:\web_projects\auth_system\resources\views/user/layouts/header.blade.php ENDPATH**/ ?>