

<?php $__env->startSection('pageTitle', 'events'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        events
                    </h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 100px">
                                        <h4 class="text-primary text-center text-capitalize">
                                            #
                                        </h4>
                                    </th>
                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Name
                                        </h4>
                                    </th>
                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Categories
                                        </h4>
                                    </th>

                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Status
                                        </h4>

                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Actions
                                        </h4>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="border: solid;">
                                            <h5 class="text-center">
                                                <?php echo e($loop->index+1); ?>

                                            </h5>
                                        </td>
                                        <td style="border: solid;">
                                            <?php echo e($event->title); ?>

                                        </td>
                                        <td style="border: solid;">
                                            <?php echo e(Str::limit($event->description, 100)); ?>

                                        </td>

                                        <td style="border: solid;">
                                            <?php if($event->finished == 0): ?>
                                                <span class="badge badge-success">Pas Fini</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Finished</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="width: 200px; border: solid;">
                                            <div class="d-flex justify-content-around flex-nowrap">
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <a href="<?php echo e(route('event.edit', $event->id)); ?>" type="button" class="btn">
                                                        <i class="mdi mdi-pencil"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('event.show', $event->id)); ?>" type="button" class="btn">
                                                        <i class="mdi mdi-eye"></i>
                                                    </a>
                                                    <form method="post" action="<?php echo e(route('event.destroy', ['event' => $event->id])); ?>">
                                                        <?php echo method_field('delete'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn ">
                                                            <i class="mdi mdi-delete"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                    </div>
                    <br>
                    <div class="d-flex justify-content-end">
                        <?php echo e($events->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/admin/event/index.blade.php ENDPATH**/ ?>