

<?php $__env->startSection('pageTitle', 'Places'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        Places
                    </h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 100px">
                                        <h4 class="text-primary text-center text-capitalize">
                                            #
                                        </h4>
                                    </th>
                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Name
                                        </h4>
                                    </th>
                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Categories
                                        </h4>
                                    </th>
                                    <th>
                                        <h4 class="text-primary text-center text-capitalize">
                                            Actions
                                        </h4>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="border: solid;">
                                            <h5 class="text-center">
                                                <?php echo e($loop->index+1); ?>

                                            </h5>
                                        </td>
                                        <td style="border: solid;">
                                            <?php echo e($place->name); ?>

                                        </td>
                                        <td style="border: solid;">
                                            <?php if(count($place->categories) == 0): ?>
                                                <p>
                                                    No categories
                                                </p>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $place->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="badge badge-info">
                                                        <?php echo e($category->name); ?>

                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php endif; ?>
                                        </td>
                                        <td style="width: 200px; border: solid;">
                                            <div class="d-flex justify-content-around flex-nowrap">
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <a href="<?php echo e(route('place.edit', $place->id)); ?>" type="button" class="btn">
                                                        <i class="mdi mdi-pencil"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('place.show', $place->id)); ?>" type="button" class="btn">
                                                        <i class="mdi mdi-eye"></i>
                                                    </a>
                                                    <form method="post" action="<?php echo e(route('place.destroy', ['place' => $place->id])); ?>">
                                                        <?php echo method_field('delete'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn ">
                                                            <i class="mdi mdi-delete"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                    </div>
                    <br>
                    <div class="d-flex justify-content-end">
                        <?php echo e($places->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\web_projects\auth_system\resources\views/admin/place/home.blade.php ENDPATH**/ ?>