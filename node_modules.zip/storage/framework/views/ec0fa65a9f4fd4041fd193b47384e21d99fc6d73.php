<div class="offcanvas-menu-overlay"></div>
    <div class="canvas-open">
        <i class="icon_menu"></i>
    </div>
    <div class="offcanvas-menu-wrapper">
        <div class="canvas-close">
            <i class="icon_close"></i>
        </div>
        
        <div class="header-configure-area">
            
            <?php if(auth()->guard()->guest()): ?>

                <?php if(Route::has('login')): ?>
                    <a class="bk-btn" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="bk-btn">Inscription</a>
                <?php endif; ?>
            <?php else: ?>
                <div class="language-option">
                    <img src="img/flag.jpg" alt="">
                    <span><?php echo e(Auth::user()->name); ?><i class="fa fa-angle-down"></i></span>
                </div>
                <a class="bk-btn" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
        </div>
        <nav class="mainmenu mobile-menu">
            <ul>
                <li class="active"><a href="./index.html">Home22</a></li>
                <li><a href="./rooms.html">Rooms</a></li>
                <li><a href="./about-us.html">About Us</a></li>
                <li><a href="./pages.html">Pages</a>
                    <ul class="dropdown">
                        <li><a href="./room-details.html">Room Details</a></li>
                        <li><a href="#">Deluxe Room</a></li>
                        <li><a href="#">Family Room</a></li>
                        <li><a href="#">Premium Room</a></li>
                    </ul>
                </li>
                <li><a href="./blog.html">News</a></li>
                <li><a href="./contact.html">Contact</a></li>
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="top-social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-tripadvisor"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
        <ul class="top-widget">
            <li><i class="fa fa-phone"></i> (12) 345 67890</li>
            <li><i class="fa fa-envelope"></i> info.colorlib@gmail.com</li>
        </ul>
</div><?php /**PATH E:\web_projects\auth_system\resources\views/user/layouts/mobilemenu.blade.php ENDPATH**/ ?>