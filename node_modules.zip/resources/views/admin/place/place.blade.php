@extends('admin.app')

@section('pageTitle', 'One Place')

@section('content')

    <h1>
        One Place
    </h1>

@endsection