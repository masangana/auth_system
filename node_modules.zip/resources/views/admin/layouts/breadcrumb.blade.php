<div class="page-header">
    <h3 class="page-title"> @yield('pageTitle') </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Charts</a></li>
        <li class="breadcrumb-item active" aria-current="page">Chart-js</li>
      </ol>
    </nav>
</div>