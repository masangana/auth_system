



<div class="col-md-8 text-center text-md-left">
    <div class="call-to-action-text">
      <h3 class="action-title">Vous aimez ce lieux liker. Il compte déjà {{ $likes}} </h3>
    </div>
</div><!-- Col end -->
<div class="col-md-4 text-center text-md-right mt-3 mt-md-0">
    <button wire:click="like" class="btn btn-primary">
        Like it2
    </button>
</div>