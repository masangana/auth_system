<?php return array (
  'filtre-events' => 'App\\Http\\Livewire\\FiltreEvents',
  'filtre-services' => 'App\\Http\\Livewire\\FiltreServices',
  'like' => 'App\\Http\\Livewire\\Like',
  'show-events' => 'App\\Http\\Livewire\\ShowEvents',
  'show-services' => 'App\\Http\\Livewire\\ShowServices',
);